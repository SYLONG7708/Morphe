/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patcher
 */

package app.morphe.patcher.resource.coder

import app.morphe.patcher.PackageMetadata
import app.morphe.patcher.Patcher
import app.morphe.patcher.PatcherResult
import app.morphe.patcher.apk.ApkUtils
import app.morphe.patcher.patch.PatchException
import app.morphe.patcher.resource.CpuArchitecture
import app.morphe.patcher.resource.PathMap
import app.morphe.patcher.resource.PublicXmlManager
import app.morphe.patcher.resource.ResourceMode
import app.morphe.patcher.resource.UncompressedFiles
import app.morphe.patcher.resource.processor.AaptMacroProcessor
import app.morphe.patcher.resource.processor.PackageRenamingProcessor
import app.morphe.patcher.resource.processor.ResourceIdProcessor
import app.morphe.patcher.resource.processor.StringsXmlEscapeProcessor
import app.morphe.patcher.resource.processor.StringsXmlSanitizeProcessor
import app.morphe.patcher.resource.processor.StringsXmlUnEscapeProcessor
import app.morphe.patcher.util.Document
import app.morphe.patcher.util.FileUtils.safelyDelete
import app.morphe.patcher.util.FileUtils.safelyMoveTo
import com.android.tools.build.apkzlib.zip.ZFile
import com.reandroid.apk.ApkModule
import com.reandroid.apk.ApkModuleRawDecoder
import com.reandroid.apk.ApkModuleXmlDecoder
import com.reandroid.apk.ApkModuleXmlEncoder
import com.reandroid.archive.InputSource
import com.reandroid.archive.block.ApkSignatureBlock
import com.reandroid.arsc.chunk.PackageBlock
import com.reandroid.arsc.coder.CoderSetting
import com.reandroid.arsc.coder.xml.AaptXmlStringDecoder
import com.reandroid.arsc.coder.xml.XmlCoder
import com.reandroid.arsc.coder.xml.XmlEncodeUtil
import com.reandroid.arsc.value.ResConfig
import com.reandroid.json.JSONObject
import com.reandroid.xml.XMLFactory
import org.w3c.dom.Element
import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.nio.file.attribute.BasicFileAttributes
import java.nio.file.attribute.FileTime
import java.util.logging.Logger
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.measureTime

/**
 * A mobile country code and a mobile network code are three digits, so a device never reports one
 * above 999. A patch that adds a resource configuration the app must never select on its own uses
 * a code of this range for one of the two.
 */
private val PATCH_MOBILE_CODES = 1000..9999

/**
 * A resource table that uses sparse entries cannot be read below Android 8.
 */
private const val SPARSE_ENTRIES_MIN_SDK = 26

/**
 * Holds the resource configurations of patches while the rest of the table is built.
 * Outside the directories the encoder scans, so that it never sees them.
 */
private const val PATCHED_CONFIGURATIONS_DIRECTORY = "patched-configurations"

/**
 * Holds root files a patch changed while the resource apk is built. Outside the directories the
 * encoder scans, so they travel through the other-files route only, instead of being compressed
 * into resources.apk as well.
 */
private const val PATCHED_ROOT_DIRECTORY = "patched-root"

/** The one archive directory left unstaged, because it dominates the APK's size. */
private const val NATIVE_LIBRARY_DIRECTORY = "lib"
private val DEX_ENTRY_NAME = Regex("classes\\d*\\.dex")

internal class ArsclibResourceCoder(
    internal val workingDir: File,
    internal val apkFile: File,
    private val keepArchitectures: Set<CpuArchitecture> = emptySet()
) : ResourceCoder {
    private val logger = Logger.getLogger(ArsclibResourceCoder::class.java.name)

    internal val packageDirectories = mutableMapOf<String, File>()
    internal val otherResourcesRootDirectory = workingDir.resolve("root")
    internal val modifiedResResources = mutableSetOf<File>()
    internal val modifiedBinaryResources = mutableSetOf<File>()

    /**
     * Set of file paths (relative to the APK root e.g: "lib/armeabi-v7a/libfoo.so")
     * that existed at decode time but no longer exist on disk after patches and
     * other transformations have run. Populated by [detectFileChanges] and returned
     * by [getDeletedFiles] so [ApkUtils.applyTo] can exclude them from the rebuilt APK.
     */
    internal val deletedFiles = mutableSetOf<String>()

    /**
     * Snapshot of file metadata and identity captured after decoding resources.
     * High-resolution timestamps and file keys improve same-size change detection when the filesystem exposes
     * distinguishable metadata, without rereading every decoded resource payload.
     */
    internal class FileSnapshot(
        val creationTime: FileTime,
        val lastModified: FileTime,
        val size: Long,
        val fileKey: Any?,
    )
    internal var fileSnapshotCache: MutableMap<String, FileSnapshot> = mutableMapOf()

    /**
     * Native libraries are left in the input APK instead of being staged to disk:
     * [reuseUnchangedArchiveEntries] carries them into the compiled resource APK without extraction.
     * They are extracted through [getFile] only when requested. Other root entries are staged
     * during decode so patches can find them by walking the directory.
     */
    private val lazilyExtractedRootFiles = mutableMapOf<String, ExtractedRootFile>()

    /** Relocated root files, mapped to the archive entry name they must be written back as. */
    private val relocatedRootFiles = mutableMapOf<String, String>()

    /**
     * Content of a root entry as extracted, for detecting whether a patch went on to change it.
     * Length is compared alongside the hash, which is [java.util.Arrays.hashCode] over the bytes:
     * fast and good enough to spot a patch's edit, but not a cryptographic digest.
     */
    internal data class ExtractedRootFile(val length: Long, val hash: Int)

    /**
     * Files are keyed by a canonical path string rather than by [File], whose equality is a plain
     * path comparison and so misses when the same file is reached by a differently spelled path.
     */
    private fun pathKey(file: File) = file.absoluteFile.invariantSeparatorsPath

    /**
     * The working directory holds *alias* paths (readable, e.g. `res/drawable-mdpi/icon.png`)
     * while the archive holds *original* entry names (often obfuscated, e.g. `res/-5N.png`).
     * [PathMap.getAlias] maps archive name to on-disk alias; [PathMap.getOriginalName] maps back.
     * Everything that crosses that boundary goes through these two helpers.
     */
    private fun archiveNameOf(aliasedPath: String) = pathMap.getOriginalName(aliasedPath) ?: aliasedPath

    private fun aliasOf(archiveName: String) = pathMap.getAlias(archiveName) ?: archiveName

    /**
     * Native library entries removed by [stripNativeLibraries], as in-APK paths.
     * Held separately from [deletedFiles] because [detectFileChanges] clears that set.
     */
    private val strippedLibraries = mutableSetOf<String>()

    /**
     * Archive entries a patch deleted by name through [deleteFile] that are not decoded resources:
     * native libraries, or root entries a patch discovered with [listApkEntries]. Held apart from
     * [deletedFiles] for the same reason as [strippedLibraries].
     */
    private val deletedArchiveEntries = mutableSetOf<String>()

    /** Entry names of the input APK, read once, since [deleteFile] is often called per entry. */
    private val apkEntryNames: Set<String> by lazy {
        ZFile.openReadOnly(apkFile).use { zFile ->
            zFile.entries().mapTo(HashSet()) { it.centralDirectoryHeader.name }
        }
    }

    /** Paths that must be stored uncompressed regardless of what the input APK did. */
    private val uncompressedOverrides = mutableSetOf<String>()
    internal var pathMap: PathMap = PathMap.EMPTY

    /**
     * Recursively scan the working directory and build a map of file paths to their metadata.
     */
    internal fun buildFileSnapshot(): MutableMap<String, FileSnapshot> {
        val snapshot = mutableMapOf<String, FileSnapshot>()
        sequenceOf(workingDir.resolve("resources"), otherResourcesRootDirectory).forEach { dir ->
            dir.walkTopDown().filter { it.isFile }.forEach { file ->
                snapshot[pathKey(file)] = file.snapshot()
            }
        }
        return snapshot
    }

    /**
     * Compare the current file state against the cached snapshot to populate
     * [modifiedResResources] and [modifiedBinaryResources].
     */
    internal fun detectFileChanges() {
        modifiedResResources.clear()
        modifiedBinaryResources.clear()
        deletedFiles.clear()

        packageDirectories.forEach { (_, packageDir) ->
            packageDir.resolve("res").walkTopDown().filter { it.isFile }.forEach { file ->
                val relativePath = file.relativeTo(packageDir).invariantSeparatorsPath
                if (excludedPaths.contains(relativePath)) return@forEach

                val cached = fileSnapshotCache[pathKey(file)]
                if (file.differsFrom(cached)) {
                    modifiedResResources.add(file)
                }
            }
        }

        otherResourcesRootDirectory.walkTopDown().filter { it.isFile }.forEach { file ->
            val extracted = lazilyExtractedRootFiles[pathKey(file)]
            if (extracted != null) {
                // Extracted mid-run, so a timestamp comparison is unreliable here; compare the
                // content instead, length first since that settles most edits without a read.
                if (file.length() != extracted.length ||
                    file.readBytes().contentHashCode() != extracted.hash
                ) modifiedBinaryResources.add(file)
                return@forEach
            }
            val cached = fileSnapshotCache[pathKey(file)]
            if (file.differsFrom(cached)) {
                modifiedBinaryResources.add(file)
            }
        }

        // Detect files that existed at decode time but are now removed.
        // These need to be communicated to applyTo() so that they're excluded from the rebuilt APK.
        val rootPathPrefix = otherResourcesRootDirectory.absoluteFile.invariantSeparatorsPath
        fileSnapshotCache.keys.forEach { key ->
            if (File(key).exists()) return@forEach
            if (key.startsWith("$rootPathPrefix/")) {
                // Snapshot keys are absolute while the working directory may be relative
                // (PatcherConfig defaults it to one), and relativising across that throws.
                // The prefix has already matched, so take the remainder of the key.
                val relativePath = key.removePrefix("$rootPathPrefix/")
                // applyTo matches against archive entry names, not on-disk aliases.
                deletedFiles += archiveNameOf(relativePath)
            }
        }
    }

    // Exclude these files from being tracked by modification/adding to prevent issues during resource encoding.
    private val excludedPaths = setOf(
        "AndroidManifest.xml",
        "res/values/public.xml",
        "res/values/ids.xml",
    )

    class PackageInfo(
        val packageName: String,
        val versionName: String,
        val versionCode: String,
        val frameworkVersion: Int,
        val signatureBlock: ApkSignatureBlock?
    )

    /**
     * `android:extractNativeLibs` as the input APK declares it. Libraries are not rebuilt into
     * resources.apk any more, so if a patch flips this the target's own libraries would keep the
     * old compression. [routeNativeLibrariesIfCompressionChanged] handles that case.
     */
    private var originalExtractNativeLibs: Boolean? = null

    private val lazyPackageInfo = lazy {
        ApkModule.loadApkFile(apkFile).use { module ->
            val manifest = module.androidManifest
            originalExtractNativeLibs = manifest.isExtractNativeLibs
            PackageInfo(
                manifest.packageName,
                manifest.versionName,
                manifest.versionCode.toString(),
                module.androidFrameworkVersion,
                module.apkSignatureBlock
            )
        }
    }

    private fun readPathMap(): PathMap {
        val pathMapJsonFile = workingDir.resolve("path-map.json")
        return if (pathMapJsonFile.exists()) {
            PathMap(pathMapJsonFile.readText(Charsets.UTF_8))
        } else {
            PathMap.EMPTY
        }
    }

    override fun getPackageMetadata(): PackageMetadata {
        return PackageMetadata(
            lazyPackageInfo.value.packageName,
            lazyPackageInfo.value.versionName,
            lazyPackageInfo.value.versionCode,
            lazyPackageInfo.value.signatureBlock
        )
    }

    override fun decodeRaw(): PackageMetadata {
        ApkModule.loadApkFile(apkFile).use { apkModule ->
            val rawDecoder = ApkModuleRawDecoder(apkModule)

            rawDecoder.setDexDecoder { _, _ -> }
            rawDecoder.dexProfileDecoder = null
            rawDecoder.decode(workingDir)
        }

        // Build a snapshot of all file metadata after decoding, so we can detect
        // which files are added or modified when it's time to encode.
        fileSnapshotCache = buildFileSnapshot()
        pathMap = readPathMap()

        return getPackageMetadata()
    }

    override fun decodeResources(): PackageMetadata {
        ApkModule.loadApkFile(apkFile).use { apkModule ->
            val xmlDecoder = object : ApkModuleXmlDecoder(apkModule) {
                override fun extractRootFiles(mainDirectory: File) {
                    var skipped = 0
                    apkModule.inputSources.forEach { source ->
                        if (!stagesRootEntry(source.alias)) {
                            addDecodedPath(source.alias)
                            skipped++
                        }
                    }
                    if (skipped != 0) logger.info("Leaving $skipped native library files in the input APK")
                    super.extractRootFiles(mainDirectory)
                }
            }.also {
                it.setKeepResPath(false)
            }

            xmlDecoder.setDexDecoder { _, _ -> }
            xmlDecoder.dexProfileDecoder = null
            xmlDecoder.decode(workingDir)

            // Update ARSCLib package metadata so the resources will be accessible under the correct package name.
            workingDir.resolve("resources").listFiles { it.isDirectory }?.forEach { dir ->
                val packageJson = JSONObject(dir.resolve("package.json"))
                val packageName = packageJson.getString("package_name")
                packageDirectories[packageName] = dir
            }
        }

        StringsXmlSanitizeProcessor(
            { path, pkg -> getFile(path, pkg) },
            packageDirectories,
        ).process()

        StringsXmlEscapeProcessor(
            { path, pkg -> getFile(path, pkg) },
            packageDirectories,
        ).process()

        // Build a snapshot of all file metadata after decoding, so we can detect
        // which files are added or modified when it's time to encode.
        // Native libraries are not staged here, and patches also add files of their own, so
        // make sure the directory exists for both.
        otherResourcesRootDirectory.mkdirs()

        fileSnapshotCache = buildFileSnapshot()
        pathMap = readPathMap()

        return getPackageMetadata()
    }

    /**
     * Remove native library directories for architectures not in [keepArchitectures].
     * This is a no-op if [keepArchitectures] is empty.
     */
    internal fun stripNativeLibraries() {
        if (keepArchitectures.isEmpty()) return

        logger.info("Stripping libs (keeping architectures " +
                "${keepArchitectures.joinToString(", ") { it.arch }})")

        // Libraries are not staged on disk, so mark them for deletion from the rebuilt APK
        // instead of deleting extracted copies. This is what NONE mode already does.
        ZFile.openReadOnly(apkFile).use { zFile ->
            zFile.entries().forEach { entry ->
                val name = entry.centralDirectoryHeader.name
                val parts = name.split("/")
                if (name.startsWith("$NATIVE_LIBRARY_DIRECTORY/") && parts.size > 1 &&
                    CpuArchitecture.valueOfOrNull(parts[1]) !in keepArchitectures
                ) {
                    strippedLibraries += name
                }
            }
        }

        // A patch may have pulled one of these in; drop the staged copy so it is not re-added.
        otherResourcesRootDirectory.resolve(NATIVE_LIBRARY_DIRECTORY)
            .takeIf { it.exists() }
            ?.listFiles { dir ->
                dir.isDirectory && CpuArchitecture.valueOfOrNull(dir.name) !in keepArchitectures
            }?.forEach { it.safelyDelete() }

        logger.info("Stripped ${strippedLibraries.size} lib files")
    }

    /**
     * If a patch changed `android:extractNativeLibs`, the native libraries the target APK already
     * holds are compressed the old way. Stage them so they travel through the other-files route
     * and are re-added with the compression the new value calls for.
     */
    private fun routeNativeLibrariesIfCompressionChanged() {
        lazyPackageInfo.value // populates originalExtractNativeLibs
        // Absent means the platform default (true since API 23), so treat it as a value rather
        // than skipping: adding or removing the attribute is exactly the interesting case.
        val original = originalExtractNativeLibs ?: true
        val current = Document(getFile("AndroidManifest.xml")).use { manifest ->
            val node = manifest.getElementsByTagName("application").item(0) as? Element
                ?: return@use null
            node.getAttribute("android:extractNativeLibs").takeIf { it.isNotEmpty() }?.toBooleanStrictOrNull()
        } ?: true
        if (current == original) return

        logger.info("extractNativeLibs changed to $current, restaging native libraries")
        val staging = workingDir.resolve(PATCHED_ROOT_DIRECTORY)
        ZFile.openReadOnly(apkFile).use { zFile ->
            zFile.entries().forEach entries@{ entry ->
                    val name = entry.centralDirectoryHeader.name
                    if (!name.startsWith("$NATIVE_LIBRARY_DIRECTORY/") || name.endsWith("/") ||
                        name in strippedLibraries || name in deletedArchiveEntries) return@entries
                    // Straight into the staging directory: these only need to reach the output,
                    // no patch is going to read them.
                    val destination = resolveInside(staging, name) ?: return@entries
                    if (!destination.exists()) {
                        destination.parentFile?.mkdirs()
                        zFile.get(name)?.open()?.use { input ->
                            destination.outputStream().use { output -> input.copyTo(output) }
                        }
                    }
                    if (destination.exists()) {
                        relocatedRootFiles[pathKey(destination)] = name
                        if (!current) uncompressedOverrides += name
                    }
                }
        }
    }

    /**
     * Move root files a patch changed out of the directory the encoder scans, so they are
     * written back through the other-files route rather than compressed into the resource apk as
     * well. Unchanged files a patch merely read are dropped, since the target APK still holds
     * them; unchanged files staged during decode are left in place for the encoder.
     */
    private fun relocateChangedRootFiles() {
        val staging = workingDir.resolve(PATCHED_ROOT_DIRECTORY)

        // An extraction a patch only read is already correct in the target apk.
        val changed = modifiedBinaryResources.mapTo(mutableSetOf()) { pathKey(it) }
        lazilyExtractedRootFiles.keys
            .filter { it !in changed }
            .forEach { File(it).safelyDelete() }

        modifiedBinaryResources.toList().forEach { file ->
            if (!file.exists()) return@forEach
            val aliased = file.relativeTo(otherResourcesRootDirectory).invariantSeparatorsPath
            val destination = staging.resolve(aliased)
            destination.parentFile?.mkdirs()
            file.safelyMoveTo(destination)
            relocatedRootFiles[pathKey(destination)] = archiveNameOf(aliased)
            modifiedBinaryResources -= file
        }
    }

    override fun encodeResources(outputDir: File): File {
        val outputApk = outputDir.resolve("resources.apk")

        stripNativeLibraries()

        // TODO: We could potentially remove unused resource splits here as well

        // Detect which files were added or modified since decoding.
        detectFileChanges()

        routeNativeLibrariesIfCompressionChanged()
        relocateChangedRootFiles()

        val newPackageName = Document(getFile("AndroidManifest.xml")).use { manifest ->
            val manifestNode = manifest.getElementsByTagName("manifest").item(0) as Element
            manifestNode.getAttribute("package")
        }
        val originalPackageName = lazyPackageInfo.value.packageName

        PublicXmlManager(getFile("res/values/public.xml")).use { publicXmlManager ->
            StringsXmlUnEscapeProcessor(
                { path, pkg -> getFile(path, pkg) },
                packageDirectories,
            ).process()

            val renamedResources = PackageRenamingProcessor(
                { path, pkg -> getFile(path, pkg) },
                publicXmlManager,
                packageDirectories,
                originalPackageName,
                newPackageName
            ).process()
            modifiedResResources += renamedResources

            // Post process all aapt:attr macros in XML files.
            AaptMacroProcessor(
                { path -> getFile(path) },
                modifiedResResources
            ).process()

            // Process all XMLs to ensure we have IDs generated for each one.
            ResourceIdProcessor(
                { path -> getFile(path) },
                publicXmlManager,
                modifiedResResources
            ).process()
        }

        logger.info("Writing resource APK")
        XmlCoder.getInstance().setting = CoderSetting().also {
            it.stringDecoder = AaptXmlStringDecoder()
        }

        val patchedConfigurations = stashPatchedConfigurations()

        try {
            val encoder = ApkModuleXmlEncoder()
            encoder.apkModule.use { loadedModule ->
                loadedModule.setPreferredFramework(lazyPackageInfo.value.frameworkVersion)

                fun Duration.roundToTenths(): Duration {
                    val roundedMs = ((inWholeMilliseconds + 50) / 100) * 100
                    return roundedMs.milliseconds
                }

                val scanDuration = measureTime {
                    encoder.scanDirectory(workingDir)
                    loadedModule.encodePatchedConfigurations(patchedConfigurations)
                }.roundToTenths()

                ApkModule.loadApkFile(apkFile).use { originalModule ->
                    val changedEntries = changedArchiveEntries(originalPackageName != newPackageName)
                    val reusedEntries = reuseUnchangedArchiveEntries(originalModule, loadedModule, changedEntries)
                    val rebuiltEntries = loadedModule.zipEntryMap.listInputSources().size - reusedEntries

                    logger.info(
                        "Resource APK inputs: reusing $reusedEntries unchanged archive entries, " +
                                "rebuilding $rebuiltEntries entries",
                    )

                    val writeDuration = measureTime {
                        loadedModule.writeApk(outputApk)
                    }.roundToTenths()

                    logger.info("Resource APK timings: scan=$scanDuration, write=$writeDuration")
                }
            }
        } finally {
            patchedConfigurations.forEach { it.restore() }
            workingDir.resolve(PATCHED_CONFIGURATIONS_DIRECTORY).safelyDelete()
        }

        return outputApk
    }

    /**
     * Returns original APK entry names which cannot be reused.
     */
    internal fun changedArchiveEntries(packageRenamed: Boolean = false): Set<String> = buildSet {
        add("AndroidManifest.xml")
        add("resources.arsc")
        addAll(deletedFiles)
        addAll(strippedLibraries)
        addAll(deletedArchiveEntries)
        addAll(relocatedRootFiles.values)

        modifiedResResources.forEach { file ->
            packageDirectories.values.firstNotNullOfOrNull { packageDirectory ->
                file.archivePathRelativeToOrNull(packageDirectory)
            }?.let(::add)
        }

        modifiedBinaryResources.forEach { file ->
            file.archivePathRelativeToOrNull(otherResourcesRootDirectory)?.let(::add)
        }

        // PackageRenamingProcessor may rewrite resource XMLs which patches did not directly touch.
        // Rebuild all compiled resources when that processor ran, while still reusing unchanged APK-root files.
        if (packageRenamed) {
            packageDirectories.values.forEach { packageDirectory ->
                packageDirectory.resolve("res").walkTopDown().filter { it.isFile }.forEach { file ->
                    file.archivePathRelativeToOrNull(packageDirectory)?.let(::add)
                }
            }
        }
    }

    /**
     * Reuses unchanged archive entries, including root files omitted by the encoder.
     * ARSCLib copies their compressed data without recompressing it.
     */
    internal fun reuseUnchangedArchiveEntries(
        originalModule: ApkModule,
        encodedModule: ApkModule,
        changedEntries: Set<String>,
    ): Int {
        val encodedEntries = encodedModule.zipEntryMap
        var reusedEntries = 0

        originalModule.zipEntryMap.listInputSources().forEach { originalSource: InputSource ->
            val entryName = originalSource.alias
            val alias = aliasOf(entryName)
            val rootEntry = !stagesRootEntry(alias) ||
                    pathKey(otherResourcesRootDirectory.resolve(alias)) in fileSnapshotCache
            if (entryName !in changedEntries && (encodedEntries.contains(entryName) || rootEntry)) {
                encodedEntries.add(originalSource)
                reusedEntries++
            }
        }

        return reusedEntries
    }

    private fun File.archivePathRelativeToOrNull(baseDirectory: File): String? {
        val filePath = absoluteFile.toPath().normalize()
        val basePath = baseDirectory.absoluteFile.toPath().normalize()
        if (!filePath.startsWith(basePath)) return null

        val alias = basePath.relativize(filePath).toString().replace(File.separatorChar, '/')
        return pathMap.getOriginalName(alias) ?: alias
    }

    /**
     * A resource configuration of a patch, held outside the working directory while the encoder
     * builds the table.
     *
     * @param publicXml The public.xml of the package the configuration belongs to, which is the
     * tag the encoder gives the package it builds from it.
     */
    internal class HeldConfiguration(
        val publicXml: File,
        private val originalDirectory: File,
        private val heldDirectory: File
    ) {
        /**
         * The directory keeps its name while it is held, so the qualifiers of the configuration
         * are still read off it.
         */
        val valuesFiles
            get() = heldDirectory.listFiles { file: File ->
                file.isFile && file.extension == "xml"
            }.orEmpty().asList()

        fun restore() = heldDirectory.safelyMoveTo(originalDirectory)
    }

    /**
     * Moves the resource configurations that patches add out of the directory the encoder scans,
     * to be encoded by [encodePatchedConfigurations] once the rest of the table stands.
     *
     * A configuration is given a dense entry table the moment the encoder creates it, sized to
     * the largest configuration of its type: an offset for every resource of the type, whether
     * this configuration defines it or not. That is a fair trade for the configurations of an
     * app, which are few and mostly populated. A patch can add more than a thousand of them to
     * select a color with, and each defines a handful of resources out of thousands. Building
     * those along with the app costs more memory than the whole rest of the table.
     *
     * A configuration of a patch is recognized by a mobile country or network code that no device
     * can report, which is how a patch keeps the app from selecting one of them on its own.
     */
    internal fun stashPatchedConfigurations(): List<HeldConfiguration> {
        val heldRoot = workingDir.resolve(PATCHED_CONFIGURATIONS_DIRECTORY)
        heldRoot.safelyDelete()

        return packageDirectories.values.flatMap { packageDirectory ->
            val publicXml = packageDirectory.resolve("res/values/public.xml")
            if (!publicXml.isFile) return@flatMap emptyList()

            packageDirectory.resolve("res").listFiles { file: File ->
                file.isDirectory && file.name.startsWith("values-")
            }.orEmpty().filter { valuesDirectory ->
                val config = ResConfig.parse(qualifiersOf(valuesDirectory))
                config.mcc in PATCH_MOBILE_CODES || config.mnc in PATCH_MOBILE_CODES
            }.map { valuesDirectory ->
                val heldDirectory = heldRoot
                    .resolve(packageDirectory.name)
                    .resolve(valuesDirectory.name)

                valuesDirectory.safelyMoveTo(heldDirectory)

                HeldConfiguration(publicXml, valuesDirectory, heldDirectory)
            }
        }.also { held ->
            if (held.isNotEmpty()) {
                logger.info("Holding back ${held.size} resource configurations of patches")
            }
        }
    }

    /**
     * Encodes the configurations [stashPatchedConfigurations] held back, into a table that is
     * already built.
     *
     * A configuration created here carries a sparse offset table, which lists only the resources
     * it defines. It is set while the configuration is still empty, so no entry table is ever
     * built for the resources it leaves out.
     *
     * Below Android 8 the resource system cannot read a sparse table, so those apps keep the
     * dense one and pay for it in memory.
     */
    private fun ApkModule.encodePatchedConfigurations(configurations: List<HeldConfiguration>) {
        if (configurations.isEmpty()) return

        val minSdk = androidManifest.minSdkVersion
        val useSparseEntries = minSdk != null && minSdk >= SPARSE_ENTRIES_MIN_SDK
        if (!useSparseEntries) {
            logger.info("Not using sparse entries, the app supports Android $minSdk")
        }

        val valuesCoder = XmlCoder.getInstance().VALUES_XML
        val encodedPackages = mutableSetOf<PackageBlock>()

        configurations.forEach { configuration ->
            val packageBlock = tableBlock.getPackageBlockByTag(configuration.publicXml)
                ?: throw PatchException(
                    "No resource package was built for ${configuration.publicXml}"
                )

            configuration.valuesFiles.forEach { valuesFile ->
                val resConfig = ResConfig.parse(
                    XmlEncodeUtil.getQualifiersFromValuesXml(valuesFile)
                )
                val specTypePair = packageBlock.getOrCreateSpecTypePair(
                    XmlEncodeUtil.getTypeFromValuesXml(valuesFile)
                )

                val denseEntryCount = specTypePair.highestEntryCount

                val typeBlock = specTypePair.getTypeBlock(resConfig)
                    ?: specTypePair.getOrCreateTypeBlock(resConfig).also {
                        if (useSparseEntries) {
                            it.headerBlock.isSparse = true
                        } else {
                            // The dense table the encoder gives a configuration of its own,
                            // sized to the largest configuration of the type
                            it.ensureEntriesCount(denseEntryCount)
                        }
                    }

                valuesCoder.encode(XMLFactory.newPullParser(valuesFile), typeBlock)
            }

            encodedPackages += packageBlock
        }

        encodedPackages.forEach { packageBlock ->
            packageBlock.sortTypes()
            packageBlock.refresh()
        }
        tableBlock.refresh()

        logger.info(
            "Encoded ${configurations.size} resource configurations of patches " +
                    "(sparse=$useSparseEntries)"
        )
    }

    /**
     * The qualifiers a resource directory carries, in the form the encoder reads them, which
     * keeps the leading separator.
     */
    private fun qualifiersOf(resourceDirectory: File): String {
        val separator = resourceDirectory.name.indexOf('-')
        return if (separator > 0) resourceDirectory.name.substring(separator) else ""
    }

    private fun File.snapshot(): FileSnapshot {
        val attributes = Files.readAttributes(toPath(), BasicFileAttributes::class.java)
        return FileSnapshot(
            attributes.creationTime(),
            attributes.lastModifiedTime(),
            attributes.size(),
            attributes.fileKey(),
        )
    }

    private fun File.differsFrom(snapshot: FileSnapshot?): Boolean {
        if (snapshot == null) return true
        val attributes = Files.readAttributes(toPath(), BasicFileAttributes::class.java)
        return attributes.creationTime() != snapshot.creationTime ||
                attributes.lastModifiedTime() != snapshot.lastModified ||
                attributes.size() != snapshot.size ||
                attributes.fileKey() != snapshot.fileKey
    }

    override fun getOtherResourceFiles(outputDir: File, resourceMode: ResourceMode): File? {
        if (resourceMode == ResourceMode.NONE) return null

        val otherResourcesDir = outputDir.resolve("other")
        otherResourcesDir.mkdirs()

        val otherFiles = mutableMapOf<File, File>()
        packageDirectories.values.forEach { packageDirectory ->
            packageDirectory.listFiles()?.filter {
                // Include any files that were copied to the resources folder root.
                // This is the equivalent of copying to the APK root when using apktool.
                // TODO: This is kind of bad. We should treat the resources folder as a read-only view and have all
                //  modified/added files end up somewhere else.

                // In RAW_ONLY mode, AndroidManifest.xml is not decoded and is named AndroidManifest.xml.bin.
                // We only want to include the manifest in this mode.
                it.isFile && it.name != "package.json" && it.name != "AndroidManifest.xml"
            }?.forEach {
                otherFiles[it] = otherResourcesDir.resolve(it.name)
            }
        }

        val workingDirPath = workingDir.absoluteFile.invariantSeparatorsPath

        // Add all touched files to the other files list in raw only mode since we won't be creating a resources.apk.
        if (resourceMode == ResourceMode.RAW_ONLY) {
            // Detect which files were added or modified since decoding.
            detectFileChanges()

            modifiedResResources.forEach {
                val path = it.absoluteFile.invariantSeparatorsPath.replace(workingDirPath, "")
                val subPath = path.substringAfter("/resources/").substringAfter("/")
                val unaliasedPath = pathMap.getOriginalName(subPath) ?: subPath
                otherFiles[it] = otherResourcesDir.resolve(unaliasedPath)
            }

            val binaryManifest = workingDir.resolve("AndroidManifest.xml.bin")
            if (binaryManifest.exists()) {
                otherFiles[binaryManifest] = workingDir.resolve("AndroidManifest.xml")
            }
        }

        // Root entries no longer travel inside resources.apk, so anything a patch added or
        // changed under root/ takes the same route raw mode has always used for them.
        // Root files a patch changed: relocated ones in FULL mode, and any still staged
        // under root/ in either mode.
        relocatedRootFiles.forEach { (key, apkPath) ->
            otherFiles[File(key)] = otherResourcesDir.resolve(apkPath)
        }
        modifiedBinaryResources.forEach {
            val path = it.absoluteFile.invariantSeparatorsPath.replace(workingDirPath, "")
            val subPath = path.substringAfter("/root/")
            val unaliasedPath = pathMap.getOriginalName(subPath) ?: subPath
            otherFiles[it] = otherResourcesDir.resolve(unaliasedPath)
        }

        return if (otherFiles.isNotEmpty()) {
            logger.info("Moving ${otherFiles.size} resource files")
            otherFiles.forEach { (src, dest) ->
                src.safelyMoveTo(dest)
            }
            otherResourcesDir
        } else {
            null
        }
    }

    override fun getUncompressedFiles(resourceMode: ResourceMode): Set<String> {
        val uncompressedJsonFile = workingDir.resolve("uncompressed-files.json")
        if (!uncompressedJsonFile.exists()) return uncompressedOverrides.toSet()

        // Defensive copy: close() clears the backing set, and applyTo commonly runs after the
        // enclosing Patcher use block. Same reason getDeletedFiles copies.
        return UncompressedFiles(
            uncompressedJsonFile.readText(Charsets.UTF_8),
            pathMap,
            uncompressedOverrides.toSet(),
        )
    }

    /**
     * Returns the relative paths (in-zip APK paths, e.g: "lib/armeabi-v7a/libfoo.so")
     * of files that existed at decode time but are no longer present on disk after
     * patches and resource transformations have run. Populated by [detectFileChanges].
     * [PatcherResult] uses this set to exclude entries from the rebuilt apk when
     * assembling the output from the original input.
     *
     * Defensive copy: [close] clears [deletedFiles], and callers commonly hold this result past
     * the enclosing [Patcher] `use` block via [PatcherResult.PatchedResources.deleteResources].
     * Returning the raw reference caused `applyTo` to read an empty set and silently skip every
     * deletion, leaving stripped native libs in the final APK. Adding a `.toSet()` returns an
     * independent snapshot instead of a live reference to [deletedFiles] `.close()` clears the
     * backing field, and `applyTo` typically runs after the [Patcher] `.use` block exits.
     */
    override fun getDeletedFiles(resourceMode: ResourceMode): Set<String> =
        if (resourceMode == ResourceMode.NONE && keepArchitectures.isNotEmpty()) {
            // When no resource patches are provided, stripNativeLibs() never got a chance to run
            // so do the filtering here
            buildSet {
                logger.info(
                    "Stripping libs (keeping architectures " +
                            "${keepArchitectures.joinToString(", ") { it.arch }})"
                )
                var strippedLibCount = 0
                ZFile.openReadOnly(apkFile).use { zFile ->
                    zFile.entries().forEach { entry ->
                        val name = entry.centralDirectoryHeader.name
                        val parts = name.split("/")
                        if (name.startsWith("$NATIVE_LIBRARY_DIRECTORY/") && parts.size > 1 &&
                            CpuArchitecture.valueOfOrNull(parts[1]) !in keepArchitectures
                        ) {
                            add(name)
                            strippedLibCount++
                        }
                    }
                }
                logger.info("Stripped $strippedLibCount lib files")
            } + deletedFiles + strippedLibraries + deletedArchiveEntries
        } else {
            deletedFiles + strippedLibraries + deletedArchiveEntries
        }

    /**
     * Get a file from the working directory.
     *
     * @param path The path of the file.
     * @param packageName The package name of the file. Defaults to the package name of the APK.
     * @param copy Unused. A path that is not staged is extracted from [apkFile] on demand
     * regardless, which is what makes native libraries reachable even though [decodeResources]
     * leaves them in the archive.
     * @return a File object representing the desired file.
     */
    override fun getFile(
        path: String,
        packageName: String?,
        copy: Boolean,
    ): File {
        val aliasedPath = pathMap.getAlias(path) ?: path

        val retval = if (aliasedPath == "res" || aliasedPath.startsWith("res/") || aliasedPath == "package.json") {
            // Only resource paths are package scoped, so do not read the manifest for the rest.
            val pkgName = packageName ?: lazyPackageInfo.value.packageName
            packageDirectories[pkgName]?.resolve(aliasedPath) ?: throw PatchException("Package $pkgName not found")
        } else if (aliasedPath == "AndroidManifest.xml") {
            // TODO: Doesn't handle modifications to binary AndroidManifest.xml, but then again neither does apktool in raw mode.
            workingDir.resolve(aliasedPath)
        } else {
            otherResourcesRootDirectory.resolve(aliasedPath).also { file ->
                if (!file.exists()) {
                    extractRootEntries(aliasedPath)
                    // Not in the archive either, so a patch is adding it; staging used to
                    // guarantee the directory existed for that.
                    if (!file.exists()) file.parentFile?.mkdirs()
                }
            }
        }

        return retval
    }

    override fun resourceIds(): Map<String, Long> =
        ApkModule.loadApkFile(apkFile).use { module ->
            if (!module.hasTableBlock()) return@use emptyMap()

            val ids = HashMap<String, Long>(1024, 0.5f)
            module.tableBlock.forEach { packageBlock ->
                packageBlock.listSpecTypePairs().forEach { specTypePair ->
                    specTypePair.forEach { typeBlock ->
                        typeBlock.listEntries(true).forEach { entry ->
                            // Unsigned: ids are 0x7fxxxxxx for the app, so this is a plain Long.
                            ids.putIfAbsent(
                                "${typeBlock.typeName}/${entry.name}",
                                entry.resourceId.toLong() and 0xffffffffL,
                            )
                        }
                    }
                }
            }
            ids
        }

    override fun listApkEntries(prefix: String): List<String> =
        ZFile.openReadOnly(apkFile).use { zFile ->
            zFile.entries().mapNotNull { entry ->
                entry.centralDirectoryHeader.name.takeIf { it.startsWith(prefix) }
            }
        }

    /**
     * Whether a root entry is staged to the working directory during decode. Everything is,
     * except native libraries and DEX files. Native libraries are the bulk of an APK, and nothing
     * enumerates them on disk. DEX files are never written by the decoder either (the DEX decoder
     * is a no-op) and are handled by the bytecode side; declaring them unstaged here lets
     * [reuseUnchangedArchiveEntries] carry them into the compiled resource APK, which is what the
     * output is built from, so they survive when no bytecode was patched.
     * Staging the rest matters because a patch that discovers files by walking the directory can
     * only see what is on disk, and the on-demand extraction in [getFile] cannot serve a walk.
     */
    internal fun stagesRootEntry(alias: String) =
        !alias.startsWith("$NATIVE_LIBRARY_DIRECTORY/") && !DEX_ENTRY_NAME.matches(alias)

    /**
     * Extract a single root entry from the input APK into the working directory, and record it
     * in the snapshot so that [detectFileChanges] treats it as pre-existing rather than added.
     * A patch that goes on to modify or delete it is then detected exactly as before.
     */
    private fun extractRootEntries(aliasedPath: String) {
        // The working directory holds on-disk alias paths, the archive holds original names.
        val apkPath = archiveNameOf(aliasedPath)
        ZFile.openReadOnly(apkFile).use { zFile ->
            val exact = zFile.get(apkPath)
            if (exact != null) {
                extractEntry(zFile, apkPath)
                return@use
            }
            // A patch may ask for a directory (and then list it), which staging used to provide.
            val prefix = "${apkPath.trimEnd('/')}/"
            zFile.entries().forEach { entry ->
                val name = entry.centralDirectoryHeader.name
                if (name.startsWith(prefix)) extractEntry(zFile, name)
            }
        }
    }

    /**
     * Resolve an archive entry name inside a directory, refusing names that escape it. Archive
     * names come from the input APK, so a crafted entry like `lib/../../x` must not become a
     * write outside the working directory. ARSCLib's own staging sanitizes names when it builds
     * its input sources; this is the equivalent guard for the paths extracted here.
     */
    private fun resolveInside(directory: File, entryName: String): File? {
        val resolved = directory.resolve(entryName).normalize().absoluteFile
        if (!resolved.startsWith(directory.normalize().absoluteFile)) {
            logger.warning("Refusing archive entry escaping the working directory: $entryName")
            return null
        }
        return resolved
    }

    private fun extractEntry(zFile: ZFile, apkPath: String) {
        val entry = zFile.get(apkPath) ?: return
        if (entry.centralDirectoryHeader.name.endsWith("/")) return
        val destination = resolveInside(otherResourcesRootDirectory, aliasOf(apkPath)) ?: return
        if (destination.exists()) return
        destination.parentFile?.mkdirs()
        entry.open().use { input ->
            destination.outputStream().use { output -> input.copyTo(output) }
        }
        if (!destination.exists()) return
        // Hash rather than (mtime, size): a patch usually rewrites the file within the same
        // filesystem timestamp tick, and same-length edits would otherwise read as unchanged.
        lazilyExtractedRootFiles[pathKey(destination)] =
            ExtractedRootFile(destination.length(), destination.readBytes().contentHashCode())
        fileSnapshotCache[pathKey(destination)] = destination.snapshot()
        logger.fine("Extracted root entry on demand: $apkPath")
    }

    /**
     * Add a file to the working directory.
     *
     * @param destPath The path of the file to add, relative to the package directory.
     * @param srcFile The file to add.
     * @param packageName The package name of the resources bundle this file should be added to. Defaults to the package name of the application. The package name should be the original package name before any patches are applied.
     * @return a File object representing the copied file.
     */
    override fun addFile(destPath: String, srcFile: File, packageName: String?): File {
        val pkgName = packageName ?: lazyPackageInfo.value.packageName
        val destFile =
            packageDirectories[pkgName]?.resolve(destPath) ?: throw PatchException("Package $pkgName not found")
        Files.copy(srcFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING)

        return destFile
    }

    override fun deleteFile(path: String, packageName: String?) {
        val alias = aliasOf(path)

        // Decoded resources are package scoped and live in the working directory; removing the
        // file there is enough, the snapshot diff reports it as deleted.
        if (alias == "res" || alias.startsWith("res/") || alias == "package.json") {
            val pkgName = packageName ?: lazyPackageInfo.value.packageName
            val packageDirectory = packageDirectories[pkgName] ?: throw PatchException("Package $pkgName not found")
            val file = resolveInside(packageDirectory, alias)
                ?: throw PatchException("Refusing to delete \"$path\": it escapes the working directory")
            Files.deleteIfExists(file.toPath())
            return
        }

        if (alias == "AndroidManifest.xml" || alias == "resources.arsc") {
            throw PatchException("\"$path\" cannot be deleted")
        }

        // Anything else is an archive entry, as named by listApkEntries. A staged copy is removed,
        // but that alone is not enough: native libraries are never staged, and a copy extracted on
        // demand is not in the decode snapshot, so its removal would only discard the extraction
        // and leave the original entry in the output. Record the entry for exclusion instead, the
        // same way stripped native libraries are.
        val staged = resolveInside(otherResourcesRootDirectory, alias)
            ?: throw PatchException("Refusing to delete \"$path\": it escapes the working directory")
        val archiveName = archiveNameOf(alias)

        // A directory, either named with a trailing slash as archives list them or staged as one,
        // stands for everything below it.
        if (alias.endsWith("/") || staged.isDirectory) {
            val prefix = "${archiveName.trimEnd('/')}/"
            val removedStagedCopies = staged.exists() && staged.deleteRecursively()
            val entries = apkEntryNames.filter { it == archiveName || it.startsWith(prefix) }
            deletedArchiveEntries += entries
            if (entries.isEmpty() && !removedStagedCopies) {
                logger.fine { "Nothing to delete for \"$path\": not a decoded resource or an APK entry" }
            }
            return
        }

        val removedStagedCopy = Files.deleteIfExists(staged.toPath())
        if (archiveName in apkEntryNames) {
            deletedArchiveEntries += archiveName
        } else if (!removedStagedCopy) {
            logger.fine { "Nothing to delete for \"$path\": not a decoded resource or an APK entry" }
        }
    }

    override fun close() {
        packageDirectories.clear()
        modifiedResResources.clear()
        modifiedBinaryResources.clear()
        deletedFiles.clear()
        lazilyExtractedRootFiles.clear()
        relocatedRootFiles.clear()
        strippedLibraries.clear()
        deletedArchiveEntries.clear()
        uncompressedOverrides.clear()
        fileSnapshotCache = mutableMapOf()
    }
}
