package app.morphe.patcher.util.proxy.mutableTypes

import app.morphe.patcher.util.proxy.mutableTypes.encodedValue.MutableEncodedValue
import app.morphe.patcher.util.proxy.mutableTypes.encodedValue.MutableEncodedValue.Companion.toMutable
import com.android.tools.smali.dexlib2.base.BaseAnnotationElement
import com.android.tools.smali.dexlib2.iface.AnnotationElement
import com.android.tools.smali.dexlib2.iface.value.EncodedValue

class MutableAnnotationElement(annotationElement: AnnotationElement) : BaseAnnotationElement() {
    private var name = annotationElement.name
    private var value = annotationElement.value.toMutable()

    fun setName(name: String) {
        this.name = name
    }

    fun setValue(value: MutableEncodedValue) {
        this.value = value
    }

    override fun getName(): String = name

    override fun getValue(): EncodedValue = value

    companion object {
        fun AnnotationElement.toMutable(): MutableAnnotationElement = MutableAnnotationElement(this)
    }
}
