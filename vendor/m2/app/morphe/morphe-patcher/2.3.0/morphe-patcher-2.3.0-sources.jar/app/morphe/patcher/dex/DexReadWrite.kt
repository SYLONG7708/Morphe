/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patcher
 */

package app.morphe.patcher.dex

import app.morphe.patcher.TaskProgress
import app.morphe.patcher.patch.PatchException
import app.morphe.patcher.util.FileUtils.safelyMoveTo
import com.android.tools.smali.dexlib2.Opcodes
import com.android.tools.smali.dexlib2.VersionMap
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile
import com.android.tools.smali.dexlib2.dexbacked.raw.HeaderItem
import com.android.tools.smali.dexlib2.iface.ClassDef
import com.android.tools.smali.dexlib2.iface.DexFile
import com.android.tools.smali.dexlib2.writer.io.FileDataStore
import com.android.tools.smali.dexlib2.writer.pool.DexPool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.runBlocking
import java.io.Closeable
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer
import java.util.Enumeration
import java.util.logging.Logger
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import kotlin.math.max
import kotlin.math.min

/**
 * The result of reading a multidex file, containing both the merged [DexFile] view
 * and the names of each individual DEX entry within the container.
 *
 * Holds the underlying memory mappings of the extracted DEX files. Call [close] to
 * deterministically release them once the [dexFile] view is no longer needed; on
 * Windows this releases the locks that would otherwise prevent the extracted files
 * from being rewritten, renamed, or deleted.
 *
 * @param dexFile A merged [DexFile] containing all classes from all DEX entries.
 * @param entryClassCounts Maps each DEX entry name to the number of classes it contains.
 * @param classDescriptorsByEntrySupplier Maps each DEX entry name to the set of class descriptors it contains.
 * @param mappedFiles The DEX files in the APK, already mapped into memory (classes.dex, classes2.dex, etc.).
 */
internal class MultidexReadResult(
    val dexFile: DexFile,
    val entryClassCounts: Map<String, Int>,
    classDescriptorsByEntrySupplier: () -> Map<String, Set<String>>,
    val mappedFiles: List<MappedFile>,
) : Closeable {
    val classDescriptorsByEntry: Map<String, Set<String>> by lazy(classDescriptorsByEntrySupplier)

    override fun close() {
        mappedFiles.forEach { it.close() }
    }
}

internal object DexReadWrite {
    private const val MIN_CLASSES_PER_SEGMENT = 250
    private const val MAX_THREADS = 4
    private val DESUGAR_NAMESPACES = setOf(
        "Lj$/",
        $$"L$r8$"
    )

    /**
     * DEX versions that [writeDexCopy] copies. Version 41 can be a container of multiple DEX files.
     */
    private const val MIN_COPIED_DEX_VERSION = 35
    private const val MAX_COPIED_DEX_VERSION = 40

    /**
     * The first DEX version with call sites and method handles.
     */
    private const val METHOD_HANDLES_DEX_VERSION = 38

    /**
     * Reads a multidex file and returns a [MultidexReadResult] containing a merged [DexFile]
     * with all classes and the names of each DEX entry within the container.
     *
     * @param inputFile The multidex file to read.
     * @param logger An optional logger to log the loading process.
     *
     * @return A [MultidexReadResult] with the merged DexFile and entry names.
     */
    internal fun readMultidexFileFromZip(inputFile: File, outputDir: File, logger: Logger? = null): MultidexReadResult {
        require(inputFile.exists()) { "input file does not exist: $inputFile" }

        val extractedFiles = extractDexEntries(inputFile, outputDir)
        logger?.info("Loaded multidex file: $inputFile with ${extractedFiles.size} dex files")

        val mappedFiles = extractedFiles.map { file -> MappedFile.mapReadWrite(file) }
        val memoryMappedDexFiles = mappedFiles.map { mappedFile ->
            CachingDexBackedDexFile(null, mappedFile.buffer)
        }
        val entryNames = extractedFiles.map { file -> file.name }

        val entryClassCounts = entryNames.zip(memoryMappedDexFiles).associate { (name, dex) ->
            name to dex.classes.size
        }

        // Track which class descriptors belong to which DEX entry lazily when requested during DEX compilation.
        val classDescriptorsByEntrySupplier = {
            entryNames.zip(memoryMappedDexFiles).associate { (name, dex) ->
                name to dex.classes.let { classes ->
                    classes.mapTo(HashSet(2 * classes.size)) { it.type }
                }
            }
        }

        val opcodes = memoryMappedDexFiles.maxByOrNull { it.opcodes.api }?.opcodes
            ?: throw PatchException("APK contains no DEX files to patch")

        val mergedClasses = memoryMappedDexFiles.flatMap { it.classes }.toSet()

        val mergedDexFile = object : DexFile {
            override fun getClasses(): Set<ClassDef> {
                return mergedClasses
            }

            override fun getOpcodes(): Opcodes {
                return opcodes
            }
        }

        return MultidexReadResult(mergedDexFile, entryClassCounts, classDescriptorsByEntrySupplier, mappedFiles)
    }

    /**
     * Extracts raw DEX entries from an APK/ZIP file directly to an output directory.
     * This reads from the zip without dexlib2 parsing, so the output files are
     * byte-identical to the original DEX data in the APK.
     *
     * @param apkFile The APK file to extract from.
     * @param outputDir The directory to write the extracted DEX files to.
     * @return A list of extracted files.
     */
    internal fun extractDexEntries(apkFile: File, outputDir: File): List<File> {
        outputDir.mkdirs()
        return ZipFile(apkFile).use { zip ->
            val outputFiles = mutableListOf<File>()
            val entriesEnumeration: Enumeration<out ZipEntry> = zip.entries()
            while (entriesEnumeration.hasMoreElements()) {
                val entry: ZipEntry = entriesEnumeration.nextElement()
                val name = entry.name
                if (!name.startsWith("classes") || !name.endsWith(".dex")) {
                    continue
                }

                // An entry such as classes/../../x.dex would otherwise be written outside outputDir
                val outputFile = outputDir.resolve(name).normalize()
                if (!outputFile.toPath().startsWith(outputDir.toPath().normalize())) {
                    throw SecurityException("DEX entry escapes the output directory: $name")
                }
                zip.getInputStream(entry).use { input ->
                    outputFile.outputStream().use { output ->
                        input.copyTo(output, bufferSize = 256 * 1024)
                    }
                    outputFiles += outputFile
                }
            }

            outputFiles
        }
    }

    /**
     * Reads a dex file from an [InputStream] and returns a [DexFile] containing all classes from the dex file.
     * @param inputStream The [InputStream] to read the dex file from.
     *
     * @return A [DexFile] containing all classes from the dex file.
     */
    internal fun readDexStream(inputStream: InputStream): DexFile {
        // This doesn't handle ODEX/OAT files, but we don't need to handle those for our use case, so it's fine.
        // Normally DexFileFactory would take care of this, but it doesn't support reading from streams, so we have to do it ourselves.

        // TODO: Load extensions in memory mapped fashion?
        return CachingDexBackedDexFile(null, inputStream.readBytes())
    }

    /**
     * Writes a copy of a DEX file that has only some of its classes, instead of writing
     * the classes with a [DexPool].
     *
     * If the DEX version of the file is newer than the version a [DexPool] writes for [opcodes],
     * the copy has the version of the [DexPool], so the classes run on the same Android versions.
     * This requires the file to use no instructions and items the older version does not support.
     *
     * @param dexBytes The contents of the DEX file.
     * @param classTypes The types of all classes of the DEX file.
     * @param keptClasses The classes of the DEX file to keep.
     * @param opcodes The opcodes a [DexPool] writes the other classes with.
     * @param outputFile The file to write the copy to.
     * @return False if the copy cannot have the DEX version of the [DexPool], and nothing was written.
     */
    internal fun writeDexCopy(
        dexBytes: ByteArray,
        classTypes: Collection<String>,
        keptClasses: Collection<ClassDef>,
        opcodes: Opcodes,
        outputFile: File,
    ): Boolean {
        // Newer versions can be a container of multiple DEX files.
        val dexVersion = HeaderItem.getVersion(dexBytes, 0)
        if (dexVersion !in MIN_COPIED_DEX_VERSION..MAX_COPIED_DEX_VERSION) return false

        val pooledDexVersion = VersionMap.mapApiToDexVersion(opcodes.api)
        if (pooledDexVersion == VersionMap.NO_VERSION) return false

        val lowerDexVersion = dexVersion > pooledDexVersion
        if (lowerDexVersion && !canLowerDexVersion(dexBytes, keptClasses, opcodes, pooledDexVersion)) return false

        val buffer = ByteBuffer.wrap(dexBytes.copyOf())
        val keptTypes = keptClasses.mapTo(HashSet()) { it.type }
        DexStripper.strip(buffer, classTypes.filterTo(HashSet()) { it !in keptTypes })
        if (lowerDexVersion) DexStripper.setDexVersion(buffer, pooledDexVersion)

        outputFile.writeBytes(buffer.array())
        return true
    }

    /**
     * If the DEX file and its kept classes use only items and instructions of [dexVersion] and [opcodes].
     */
    private fun canLowerDexVersion(
        dexBytes: ByteArray,
        keptClasses: Collection<ClassDef>,
        opcodes: Opcodes,
        dexVersion: Int,
    ): Boolean {
        if (dexVersion < METHOD_HANDLES_DEX_VERSION) {
            val dexFile = DexBackedDexFile(null, ByteBuffer.wrap(dexBytes))
            if (dexFile.callSiteSection.isNotEmpty() || dexFile.methodHandleSection.isNotEmpty()) return false
        }

        return keptClasses.parallelStream().allMatch { classDef ->
            classDef.methods.all { method ->
                method.implementation?.instructions?.all { instruction ->
                    opcodes.getOpcodeValue(instruction.opcode) != null
                } ?: true
            }
        }
    }

    /**
     * Writes a [DexFile] to the specified output directory.
     * The dex file will be split into multiple dex files if it exceeds the dex size limit.
     * @param outputDir The directory to write the multidex file to.
     * @param classDefs The class definitions to write. This collection will be cleared after splitting into segments.
     * @param opcodes The [Opcodes] to use for the dex files.
     * @param maxThreads The maximum number of threads to use for writing the dex files.
     * @param progress Counts the classes as they are written, after adding them to its total.
     *
     * @return A list of [File]s representing the written dex files.
     */
    internal fun writeMultiDexFile(
        outputDir: File,
        classDefs: MutableCollection<ClassDef>,
        opcodes: Opcodes,
        maxThreads: Int = -1,
        logger: Logger? = null,
        progress: TaskProgress? = null,
    ): List<File> {
        require(!outputDir.exists() || outputDir.isDirectory) { "Output path must be a directory: $outputDir" }

        if (outputDir.exists()) {
            outputDir.deleteRecursively()
        }
        outputDir.mkdirs()

        val availableProcessors = Runtime.getRuntime().availableProcessors()
        val actualMaxThreads = if (maxThreads < 1) {
            min(availableProcessors, MAX_THREADS)
        } else {
            min(min(maxThreads, MAX_THREADS), availableProcessors)
        }

        val numClasses = classDefs.size
        progress?.expand(numClasses.toLong())

        val numSegments = max(1, min(actualMaxThreads, numClasses / MIN_CLASSES_PER_SEGMENT))

        // Split into independent mutable lists and clear the original collection to reduce memory usage.
        val segments = splitIntoMutableSegments(classDefs, numSegments)
        classDefs.clear()

        val segmentResults = if (numSegments == 1) {
            logger?.info("Processing $numClasses classes (single threaded mode)")

            segments.mapIndexed { index, segment ->
                processSegment(segment, opcodes, outputDir, index, progress)
            }
        } else {
            logger?.info("Processing $numClasses classes in parallel (${actualMaxThreads} threads)")

            val dispatcher = Dispatchers.Default.limitedParallelism(numSegments)
            runBlocking(dispatcher) {
                segments.mapIndexed { segmentIndex, classQueue ->
                    async {
                        processSegment(classQueue, opcodes, outputDir, segmentIndex, progress)
                    }
                }.awaitAll()
            }
        }

        // Rename temp files to final dex files
        val dexFiles = mutableListOf<File>()
        for (tempFiles in segmentResults) {
            for (tempFile in tempFiles) {
                val fileName = if (dexFiles.isEmpty()) "classes.dex" else "classes${dexFiles.size + 1}.dex"
                val finalFile = outputDir.resolve(fileName)
                tempFile.safelyMoveTo(finalFile)
                dexFiles.add(finalFile)
            }
        }

        logger?.info("Wrote ${dexFiles.size} dex files to $outputDir")
        return dexFiles
    }

    /**
     * Splits a collection into [numSegments] independent mutable lists of roughly equal size.
     * Unlike [List.subList], the returned lists do not share backing storage with each other
     * or the source collection, so they can be independently cleared to free memory.
     */
    private fun splitIntoMutableSegments(collection: Collection<ClassDef>, numSegments: Int): List<ArrayDeque<ClassDef>> {
        var requestedSegments = if (numSegments <= 1) {
            1
        } else {
            numSegments
        }
        val segments = mutableListOf<ArrayDeque<ClassDef>>()

        // Separate out any j$ classes into their own DEX files, because d8/r8 will reject the DEX files otherwise.
        val desugarClassDefs: List<ClassDef> = collection.filter { isDesugarLib(it) }
        if (desugarClassDefs.isNotEmpty()) {
            segments.add(ArrayDeque(desugarClassDefs))
            if (requestedSegments > 1) {
                requestedSegments--
            }
        }

        val list = collection.filter { !isDesugarLib(it) }
        val segmentSize = list.size / requestedSegments
        val remainder = list.size % requestedSegments
        var offset = 0

        for (i in 0 until requestedSegments) {
            // Distribute the remainder across the first segments (one extra element each).
            val size = segmentSize + if (i < remainder) 1 else 0
            segments.add(ArrayDeque(list.subList(offset, offset + size)))
            offset += size
        }

        return segments
    }

    /**
     * Processes a segment of classes: fills one or more [DexPool]s and writes each to a temp file.
     * Returns the list of temp files in the order they were produced.
     */
    private fun processSegment(
        classQueue: ArrayDeque<ClassDef>,
        opcodes: Opcodes,
        outputDir: File,
        segmentIndex: Int,
        progress: TaskProgress?,
    ): List<File> {
        val tempFiles = mutableListOf<File>()
        var currentDexPool = DexPool(opcodes)

        while (classQueue.isNotEmpty()) {
            val classDef = classQueue.first()

            currentDexPool.mark()
            currentDexPool.internClass(classDef)
            if (currentDexPool.hasOverflowed()) {
                currentDexPool.reset()
                tempFiles.add(writeDexPoolToTemp(currentDexPool, outputDir, segmentIndex, tempFiles.size))
                currentDexPool = DexPool(opcodes)
            } else {
                classQueue.removeFirst()
                progress?.advance()
            }
        }

        tempFiles.add(writeDexPoolToTemp(currentDexPool, outputDir, segmentIndex, tempFiles.size))
        return tempFiles
    }

    /**
     * Writes a [DexPool] to a temporary file within the output directory.
     * The temp file is named using the segment and pool indices to avoid collisions.
     */
    private fun writeDexPoolToTemp(dexPool: DexPool, outputDir: File, segmentIndex: Int, poolIndex: Int): File {
        val tempFile = outputDir.resolve(".tmp_seg${segmentIndex}_${poolIndex}.dex")
        dexPool.writeTo(FileDataStore(tempFile))
        return tempFile
    }

    internal fun isDesugarLib(classDef: ClassDef): Boolean {
        return DESUGAR_NAMESPACES.any { classDef.type.startsWith(it) }
    }
}